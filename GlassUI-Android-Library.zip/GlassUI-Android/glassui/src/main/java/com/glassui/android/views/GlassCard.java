package com.glassui.android.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.*;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.glassui.android.GlassConfig;
import com.glassui.android.GlassRenderer;
import com.glassui.android.R;
import com.glassui.android.utils.GlassAttrReader;

/**
 * GlassCard — A glass-styled card panel with optional title header.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * XML:
 *   <com.glassui.android.views.GlassCard
 *       android:layout_width="match_parent"
 *       android:layout_height="wrap_content"
 *       app:glass_theme="dark"
 *       app:glass_corner_radius="20dp"
 *       app:glass_card_title="User Stats"
 *       app:glass_card_title_size="14sp"
 *       app:glass_header_divider="true">
 *
 *       <!-- Content goes here as direct children -->
 *       <TextView android:text="Hello" ... />
 *
 *   </com.glassui.android.views.GlassCard>
 *
 * ─────────────────────────────────────────────────────────────────────────
 * Java:
 *   GlassCard card = new GlassCard(context);
 *   card.setGlassConfig(GlassConfig.NEON_BLUE());
 *   card.setCardTitle("Stats");
 *   card.addView(myContentView);
 * ─────────────────────────────────────────────────────────────────────────
 *
 * @version 1.0
 */
public class GlassCard extends FrameLayout {

    private GlassRenderer renderer;
    private GlassConfig config;

    // Title header
    private String cardTitle     = null;
    private float  titleTextSize = 14f;   // sp
    private int    headerHeight  = 0;     // px
    private boolean headerDivider = true;

    // Paints
    private final Paint titlePaint     = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dividerPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ─── Constructors ─────────────────────────────────────────────────────

    public GlassCard(Context context) {
        super(context); init(context, null);
    }

    public GlassCard(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }

    public GlassCard(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr); init(context, attrs);
    }

    // ─── Init ─────────────────────────────────────────────────────────────

    private void init(Context ctx, AttributeSet attrs) {
        setWillNotDraw(false);
        setBackground(null);

        config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();

        if (attrs != null) {
            TypedArray a = ctx.obtainStyledAttributes(attrs, R.styleable.GlassCard);
            cardTitle   = a.getString(R.styleable.GlassCard_glass_card_title);
            titleTextSize = a.getDimension(R.styleable.GlassCard_glass_card_title_size,
                    spToPx(ctx, 14));
            headerHeight = (int) a.getDimension(R.styleable.GlassCard_glass_header_height,
                    dpToPx(ctx, 48));
            headerDivider = a.getBoolean(R.styleable.GlassCard_glass_header_divider, true);
            a.recycle();
        } else {
            headerHeight = (int) dpToPx(ctx, 48);
        }

        renderer = new GlassRenderer(config);
        setupPaints();
        updatePadding();
    }

    private void setupPaints() {
        titlePaint.setColor(config.textColor);
        titlePaint.setTextSize(titleTextSize);
        titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        int bc = config.getBorderPaintColor();
        dividerPaint.setColor(Color.argb(60,
                Color.red(bc), Color.green(bc), Color.blue(bc)));
        dividerPaint.setStrokeWidth(1f);
    }

    private void updatePadding() {
        int top = (cardTitle != null) ? headerHeight : 0;
        int pad = (int) dpToPx(getContext(), 16);
        setPadding(pad, top + pad, pad, pad);
    }

    // ─── Drawing ──────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();

        // Glass background
        renderer.draw(canvas, 0, 0, w, h);

        // Header
        if (cardTitle != null) {
            // Divider line
            if (headerDivider) {
                float cr = config.cornerRadiusTL;
                canvas.drawLine(cr, headerHeight, w - cr, headerHeight, dividerPaint);
            }

            // Title text
            float textX = dpToPx(getContext(), 16);
            FontMetrics fm = titlePaint.getFontMetrics();
            float textY = headerHeight / 2f - (fm.ascent + fm.descent) / 2f;
            canvas.drawText(cardTitle, textX, textY, titlePaint);
        }

        super.onDraw(canvas);
    }

    // ─── Config API ───────────────────────────────────────────────────────

    public GlassCard setGlassConfig(GlassConfig config) {
        this.config = config;
        renderer.setConfig(config);
        setupPaints();
        invalidate();
        return this;
    }

    public GlassCard setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }

    public GlassCard setCardTitle(String title) {
        cardTitle = title;
        updatePadding();
        invalidate();
        return this;
    }

    public GlassCard setHeaderDivider(boolean show) {
        headerDivider = show;
        invalidate();
        return this;
    }

    // ─── Helpers ──────────────────────────────────────────────────────────

    private static float dpToPx(Context ctx, float dp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                ctx.getResources().getDisplayMetrics());
    }

    private static float spToPx(Context ctx, float sp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp,
                ctx.getResources().getDisplayMetrics());
    }
}
