package com.glassui.android.views;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.*;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import com.glassui.android.GlassConfig;
import com.glassui.android.GlassRenderer;
import com.glassui.android.R;
import com.glassui.android.utils.GlassAttrReader;

import java.util.ArrayList;
import java.util.List;

// ═══════════════════════════════════════════════════════════════════════════
//  GlassProgressBar
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GlassProgressBar — Animated glass-styled progress bar.
 *
 * XML:
 *   <com.glassui.android.views.GlassProgressBar
 *       android:layout_width="match_parent"
 *       android:layout_height="20dp"
 *       app:glass_theme="neon_blue"
 *       app:glass_progress="0.65"
 *       app:glass_show_label="true"
 *       app:glass_animate_on_attach="true" />
 *
 * Java:
 *   GlassProgressBar bar = new GlassProgressBar(context);
 *   bar.setGlassConfig(GlassConfig.AURORA());
 *   bar.setProgress(0.75f);   // animated
 */
public class GlassProgressBar extends View {

    private GlassRenderer renderer;
    private GlassConfig config;

    private float targetProgress  = 0f;
    private float currentProgress = 0f;
    private boolean showLabel     = true;
    private boolean animateOnAttach = true;
    private String customLabel    = null;

    private ValueAnimator progressAnimator;

    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ─── Constructors ─────────────────────────────────────────────────────

    public GlassProgressBar(Context context) {
        super(context); init(context, null);
    }

    public GlassProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }

    public GlassProgressBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle); init(context, attrs);
    }

    // ─── Init ─────────────────────────────────────────────────────────────

    private void init(Context ctx, AttributeSet attrs) {
        config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();

        if (attrs != null) {
            TypedArray a = ctx.obtainStyledAttributes(attrs, R.styleable.GlassProgressBar);
            targetProgress   = a.getFloat(R.styleable.GlassProgressBar_glass_progress, 0f);
            showLabel        = a.getBoolean(R.styleable.GlassProgressBar_glass_show_label, true);
            animateOnAttach  = a.getBoolean(R.styleable.GlassProgressBar_glass_animate_on_attach, true);
            a.recycle();
        }

        renderer = new GlassRenderer(config);

        labelPaint.setTextSize(spToPx(ctx, 10));
        labelPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        labelPaint.setColor(config.textColor);

        progressAnimator = new ValueAnimator();
        progressAnimator.setDuration(600);
        progressAnimator.setInterpolator(new DecelerateInterpolator());
        progressAnimator.addUpdateListener(a -> {
            currentProgress = (float) a.getAnimatedValue();
            invalidate();
        });

        if (!animateOnAttach) {
            currentProgress = targetProgress;
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (animateOnAttach && targetProgress > 0) {
            progressAnimator.setFloatValues(0f, targetProgress);
            progressAnimator.start();
        }
    }

    // ─── Drawing ──────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        renderer.drawProgress(canvas, 0, 0, w, h, currentProgress);

        if (showLabel) {
            String label = customLabel != null ? customLabel
                    : Math.round(currentProgress * 100) + "%";
            float tw = labelPaint.measureText(label);
            FontMetrics fm = labelPaint.getFontMetrics();
            float tx = (w - tw) / 2f;
            float ty = h / 2f - (fm.ascent + fm.descent) / 2f;
            canvas.drawText(label, tx, ty, labelPaint);
        }
    }

    // ─── Config API ───────────────────────────────────────────────────────

    /** Set progress 0.0–1.0 with smooth animation */
    public GlassProgressBar setProgress(float progress) {
        float from = currentProgress;
        targetProgress = Math.max(0f, Math.min(1f, progress));
        progressAnimator.cancel();
        progressAnimator.setFloatValues(from, targetProgress);
        progressAnimator.start();
        return this;
    }

    /** Set progress immediately without animation */
    public GlassProgressBar setProgressImmediate(float progress) {
        progressAnimator.cancel();
        targetProgress = currentProgress = Math.max(0f, Math.min(1f, progress));
        invalidate();
        return this;
    }

    public GlassProgressBar setShowLabel(boolean show) {
        showLabel = show; invalidate(); return this;
    }

    public GlassProgressBar setCustomLabel(String label) {
        customLabel = label; invalidate(); return this;
    }

    public GlassProgressBar setGlassConfig(GlassConfig config) {
        this.config = config;
        renderer.setConfig(config);
        labelPaint.setColor(config.textColor);
        invalidate();
        return this;
    }

    public GlassProgressBar setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }

    public float getProgress() { return targetProgress; }

    private float spToPx(Context ctx, float sp) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp,
                ctx.getResources().getDisplayMetrics());
    }
}


// ═══════════════════════════════════════════════════════════════════════════
//  GlassSlider
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GlassSlider — Custom glass-styled SeekBar alternative.
 *
 * XML:
 *   <com.glassui.android.views.GlassSlider
 *       android:layout_width="match_parent"
 *       android:layout_height="40dp"
 *       app:glass_theme="neon_pink"
 *       app:glass_min="0"
 *       app:glass_max="100"
 *       app:glass_value="50" />
 *
 * Java:
 *   slider.addChangeListener(value -> Log.d("TAG", "Value: " + value));
 */
class GlassSlider extends View {

    public interface OnChangeListener { void onValueChanged(int value); }

    private GlassConfig config;
    private GlassRenderer renderer;

    private int min = 0, max = 100, value = 50;
    private boolean dragging = false;

    // Thumb glow
    private float thumbGlow = 0f;
    private ValueAnimator glowAnimator;

    private final Paint trackPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF trackRect   = new RectF();
    private final RectF fillRect    = new RectF();

    private final List<OnChangeListener> listeners = new ArrayList<>();

    // ─── Constructors ─────────────────────────────────────────────────────

    public GlassSlider(Context context) {
        super(context); init(context, null);
    }

    public GlassSlider(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }

    public GlassSlider(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle); init(context, attrs);
    }

    // ─── Init ─────────────────────────────────────────────────────────────

    private void init(Context ctx, AttributeSet attrs) {
        config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();

        if (attrs != null) {
            TypedArray a = ctx.obtainStyledAttributes(attrs, R.styleable.GlassSlider);
            min   = a.getInt(R.styleable.GlassSlider_glass_min,   0);
            max   = a.getInt(R.styleable.GlassSlider_glass_max,   100);
            value = a.getInt(R.styleable.GlassSlider_glass_value, 50);
            a.recycle();
        }

        renderer = new GlassRenderer(config);

        // Glow animation
        glowAnimator = new ValueAnimator();
        glowAnimator.setDuration(200);
        glowAnimator.setInterpolator(new DecelerateInterpolator());
        glowAnimator.addUpdateListener(a -> {
            thumbGlow = (float) a.getAnimatedValue();
            invalidate();
        });
    }

    // ─── Touch ────────────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int w = getWidth();
        int thumbR = getHeight() / 2;
        int trackStart = thumbR;
        int trackEnd = w - thumbR;

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                animateGlow(1f);
                updateValueFromX(event.getX(), trackStart, trackEnd);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (dragging) updateValueFromX(event.getX(), trackStart, trackEnd);
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                animateGlow(0f);
                return true;
        }
        return super.onTouchEvent(event);
    }

    private void animateGlow(float target) {
        glowAnimator.cancel();
        glowAnimator.setFloatValues(thumbGlow, target);
        glowAnimator.start();
    }

    private void updateValueFromX(float x, int trackStart, int trackEnd) {
        float frac = (x - trackStart) / (float)(trackEnd - trackStart);
        frac = Math.max(0f, Math.min(1f, frac));
        int newVal = min + Math.round(frac * (max - min));
        if (newVal != value) {
            value = newVal;
            invalidate();
            for (OnChangeListener l : listeners) l.onValueChanged(value);
        }
    }

    // ─── Drawing ──────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        int thumbR   = h / 2;
        int trackH   = (int)(h * 0.30f);
        int trackStart = thumbR;
        int trackEnd   = w - thumbR;
        int cy = h / 2;

        float frac = (max > min) ? (float)(value - min) / (max - min) : 0f;
        int thumbX = trackStart + (int)(frac * (trackEnd - trackStart));

        // Track (inset glass)
        trackRect.set(trackStart, cy - trackH / 2f, trackEnd, cy + trackH / 2f);
        renderer.drawInset(canvas, trackRect.left, trackRect.top, trackRect.right, trackRect.bottom);

        // Fill bar
        if (frac > 0.005f) {
            fillRect.set(trackStart, cy - trackH / 2f,
                    Math.max(trackStart + trackH, thumbX), cy + trackH / 2f);
            int bc = config.borderColor;
            fillPaint.setShader(new LinearGradient(
                    fillRect.left, fillRect.top, fillRect.left, fillRect.bottom,
                    Color.argb(210, Color.red(bc), Color.green(bc), Color.blue(bc)),
                    Color.argb(130, Color.red(bc), Color.green(bc), Color.blue(bc)),
                    Shader.TileMode.CLAMP));
            canvas.drawRoundRect(fillRect, trackH / 2f, trackH / 2f, fillPaint);
            fillPaint.setShader(null);
        }

        // Thumb glow
        if (thumbGlow > 0.05f) {
            int bc = config.borderColor;
            for (int i = (int)(thumbGlow * 6); i >= 1; i--) {
                float fr = (float) i / 6;
                int alpha = (int)(thumbGlow * 100 * (1f - fr));
                glowPaint.setColor(Color.argb(alpha,
                        Color.red(bc), Color.green(bc), Color.blue(bc)));
                glowPaint.setMaskFilter(new BlurMaskFilter(i * 3f, BlurMaskFilter.Blur.NORMAL));
                canvas.drawCircle(thumbX, cy, thumbR + i, glowPaint);
            }
        }

        // Thumb
        renderer.draw(canvas,
                thumbX - thumbR, cy - thumbR,
                thumbX + thumbR, cy + thumbR);
    }

    // ─── Config API ───────────────────────────────────────────────────────

    public GlassSlider setGlassConfig(GlassConfig config) {
        this.config = config;
        renderer.setConfig(config);
        invalidate();
        return this;
    }

    public GlassSlider setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }

    public int getValue()  { return value; }

    public GlassSlider setValue(int v) {
        value = Math.max(min, Math.min(max, v));
        invalidate();
        return this;
    }

    public GlassSlider addChangeListener(OnChangeListener l) {
        listeners.add(l); return this;
    }
}
