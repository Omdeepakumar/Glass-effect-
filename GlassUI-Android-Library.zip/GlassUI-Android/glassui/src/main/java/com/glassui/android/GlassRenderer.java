package com.glassui.android;

import android.graphics.*;
import android.os.Build;

/**
 * GlassRenderer — Core drawing engine for all GlassUI components.
 *
 * Draws glassmorphism onto an Android Canvas:
 *  1. Drop shadow / glow
 *  2. Glass fill (semi-transparent color)
 *  3. Top highlight gradient
 *  4. Optional noise texture
 *  5. Border stroke
 *
 * All methods are stateless — pass Canvas + GlassConfig + bounds.
 *
 * Usage:
 *   GlassRenderer renderer = new GlassRenderer();
 *   renderer.setConfig(config);
 *   renderer.draw(canvas, 0, 0, getWidth(), getHeight());
 */
public class GlassRenderer {

    private GlassConfig config;

    // Reusable paint objects (avoid allocation in draw)
    private final Paint fillPaint    = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint borderPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint highlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint noisePaint   = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Path  path         = new Path();
    private final RectF rectF        = new RectF();

    // Noise bitmap (generated once)
    private Bitmap noiseBitmap;
    private static final int NOISE_SIZE = 128;

    // ─────────────────────────────────────────────────────────────────────

    public GlassRenderer() {
        this(GlassConfig.FROST());
    }

    public GlassRenderer(GlassConfig config) {
        setConfig(config);
    }

    public void setConfig(GlassConfig config) {
        this.config = config;
        setupPaints();
        if (config.noiseEnabled && noiseBitmap == null) {
            noiseBitmap = generateNoiseBitmap();
        }
    }

    public GlassConfig getConfig() { return config; }

    // ─── Setup ───────────────────────────────────────────────────────────

    private void setupPaints() {
        // Fill
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(config.getGlassFillColor());

        // Border
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setColor(config.getBorderPaintColor());
        borderPaint.setStrokeWidth(config.borderWidth);
        borderPaint.setStrokeCap(Paint.Cap.ROUND);
        borderPaint.setStrokeJoin(Paint.Join.ROUND);

        // Highlight (set shader when size is known)
        highlightPaint.setStyle(Paint.Style.FILL);

        // Noise
        if (config.noiseEnabled) {
            noisePaint.setAlpha(config.noiseAlpha);
        }

        // Shadow — use setShadowLayer on fill paint for hardware-accelerated paths
        // We handle shadow separately for better control
        shadowPaint.setStyle(Paint.Style.FILL);
        shadowPaint.setColor(config.getShadowPaintColor());
        if (config.blurEnabled || config.shadowRadius > 0) {
            shadowPaint.setMaskFilter(new BlurMaskFilter(
                    config.shadowRadius, BlurMaskFilter.Blur.NORMAL));
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  MAIN DRAW
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Draw complete glass surface at the given bounds.
     *
     * @param canvas  Android Canvas
     * @param l       left
     * @param t       top
     * @param r       right
     * @param b       bottom
     */
    public void draw(Canvas canvas, float l, float t, float r, float b) {
        buildPath(l, t, r, b);
        float w = r - l;
        float h = b - t;

        // 1. Shadow / glow
        drawShadow(canvas, l, t, r, b);

        // 2. Glass fill
        canvas.drawPath(path, fillPaint);

        // 3. Highlight gradient (top shimmer)
        drawHighlight(canvas, l, t, w, h);

        // 4. Noise texture
        if (config.noiseEnabled && noiseBitmap != null) {
            drawNoise(canvas, l, t, w, h);
        }

        // 5. Border
        canvas.drawPath(path, borderPaint);
    }

    // ─── Shadow ──────────────────────────────────────────────────────────

    private void drawShadow(Canvas canvas, float l, float t, float r, float b) {
        if (config.shadowOpacity <= 0.01f) return;

        float dx = config.shadowDx;
        float dy = config.shadowDy;
        float radius = config.shadowRadius;
        int steps = 8;

        for (int i = steps; i >= 1; i--) {
            float fraction = (float) i / steps;
            float expansion = fraction * radius * 0.3f;
            float alpha = config.shadowOpacity * (1f - fraction) * 0.7f;
            int a = Math.max(0, Math.min(255, (int)(alpha * 255)));

            int sc = config.shadowColor;
            shadowPaint.setColor(Color.argb(a,
                    Color.red(sc), Color.green(sc), Color.blue(sc)));
            shadowPaint.setMaskFilter(new BlurMaskFilter(
                    radius * fraction * 0.8f + 1f, BlurMaskFilter.Blur.NORMAL));

            RectF shadowRect = new RectF(
                    l - expansion + dx,
                    t - expansion + dy,
                    r + expansion + dx,
                    b + expansion + dy);
            canvas.drawRoundRect(shadowRect,
                    config.cornerRadiusTL + expansion,
                    config.cornerRadiusTL + expansion,
                    shadowPaint);
        }
    }

    // ─── Highlight ────────────────────────────────────────────────────────

    private void drawHighlight(Canvas canvas, float l, float t, float w, float h) {
        if (config.highlightOpacity <= 0.01f) return;

        int hiColor = config.getHighlightColor();
        int hiTrans = Color.argb(0, Color.red(hiColor), Color.green(hiColor), Color.blue(hiColor));

        LinearGradient shader = new LinearGradient(
                l, t, l, t + h * 0.55f,
                hiColor, hiTrans,
                Shader.TileMode.CLAMP);
        highlightPaint.setShader(shader);

        int saved = canvas.save();
        canvas.clipPath(path);
        canvas.drawRect(l, t, l + w, t + h, highlightPaint);
        canvas.restoreToCount(saved);
        highlightPaint.setShader(null);
    }

    // ─── Noise ────────────────────────────────────────────────────────────

    private void drawNoise(Canvas canvas, float l, float t, float w, float h) {
        int saved = canvas.save();
        canvas.clipPath(path);
        BitmapShader shader = new BitmapShader(noiseBitmap,
                Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        noisePaint.setShader(shader);
        canvas.drawRect(l, t, l + w, t + h, noisePaint);
        canvas.restoreToCount(saved);
        noisePaint.setShader(null);
    }

    // ─── Path builder ─────────────────────────────────────────────────────

    private void buildPath(float l, float t, float r, float b) {
        path.reset();
        float tl = config.cornerRadiusTL;
        float tr = config.cornerRadiusTR;
        float br = config.cornerRadiusBR;
        float bl = config.cornerRadiusBL;

        // Check if all corners equal (fast path)
        if (tl == tr && tr == br && br == bl) {
            rectF.set(l, t, r, b);
            path.addRoundRect(rectF, tl, tl, Path.Direction.CW);
        } else {
            // Per-corner radii
            float[] radii = { tl, tl, tr, tr, br, br, bl, bl };
            rectF.set(l, t, r, b);
            path.addRoundRect(rectF, radii, Path.Direction.CW);
        }
        path.close();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SPECIAL DRAWS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Draw a glow ring around the bounds (for focus/hover).
     *
     * @param color  glow color
     * @param alpha  0–255
     * @param radius glow spread in px
     */
    public void drawGlow(Canvas canvas, float l, float t, float r, float b,
                         int color, int alpha, float radius) {
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(radius);
        glow.setColor(Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color)));
        glow.setMaskFilter(new BlurMaskFilter(radius, BlurMaskFilter.Blur.NORMAL));

        float expand = radius * 0.5f;
        RectF glowRect = new RectF(l - expand, t - expand, r + expand, b + expand);
        float cr = config.cornerRadiusTL + expand;
        canvas.drawRoundRect(glowRect, cr, cr, glow);
    }

    /**
     * Draw an inset (darker) glass fill — used for EditText backgrounds.
     */
    public void drawInset(Canvas canvas, float l, float t, float r, float b) {
        buildPath(l, t, r, b);
        float h = b - t;

        // Darker fill
        int base = config.glassColor;
        int darker = Color.argb(
                (int)(config.glassOpacity * 255 * 1.4f),
                Math.max(0, Color.red(base)   - 25),
                Math.max(0, Color.green(base) - 25),
                Math.max(0, Color.blue(base)  - 25));
        fillPaint.setColor(darker);
        canvas.drawPath(path, fillPaint);
        fillPaint.setColor(config.getGlassFillColor()); // restore

        // Inner top shadow
        int saved = canvas.save();
        canvas.clipPath(path);
        Paint innerShadow = new Paint(Paint.ANTI_ALIAS_FLAG);
        innerShadow.setShader(new LinearGradient(
                l, t, l, t + Math.min(h * 0.35f, 20f),
                Color.argb(70, 0, 0, 0),
                Color.argb(0, 0, 0, 0),
                Shader.TileMode.CLAMP));
        canvas.drawRect(l, t, r, b, innerShadow);
        canvas.restoreToCount(saved);

        canvas.drawPath(path, borderPaint);
    }

    /**
     * Draw a progress bar (track + filled bar).
     *
     * @param progress 0.0 – 1.0
     */
    public void drawProgress(Canvas canvas, float l, float t, float r, float b,
                             float progress) {
        float h = b - t;
        float cr = h / 2f;

        // Track
        drawInset(canvas, l, t, r, b);

        // Fill bar
        if (progress > 0.005f) {
            float fillRight = l + Math.max(cr * 2, (r - l) * progress);

            Paint fillBar = new Paint(Paint.ANTI_ALIAS_FLAG);
            int bc = config.borderColor;
            LinearGradient barGrad = new LinearGradient(
                    l, t, l, b,
                    Color.argb(210, Color.red(bc), Color.green(bc), Color.blue(bc)),
                    Color.argb(130, Color.red(bc), Color.green(bc), Color.blue(bc)),
                    Shader.TileMode.CLAMP);
            fillBar.setShader(barGrad);

            RectF fillRect = new RectF(l, t, fillRight, b);
            Path fillPath = new Path();
            fillPath.addRoundRect(fillRect, cr, cr, Path.Direction.CW);
            canvas.drawPath(fillPath, fillBar);

            // Shine on bar
            int sv = canvas.save();
            canvas.clipPath(fillPath);
            Paint shine = new Paint(Paint.ANTI_ALIAS_FLAG);
            shine.setShader(new LinearGradient(l, t, l, t + h / 2f,
                    Color.argb(90, 255, 255, 255),
                    Color.argb(0, 255, 255, 255),
                    Shader.TileMode.CLAMP));
            canvas.drawRect(l, t, fillRight, b, shine);
            canvas.restoreToCount(sv);
        }
    }

    // ─── Noise bitmap generator ───────────────────────────────────────────

    private static Bitmap generateNoiseBitmap() {
        Bitmap bmp = Bitmap.createBitmap(NOISE_SIZE, NOISE_SIZE, Bitmap.Config.ARGB_8888);
        int[] pixels = new int[NOISE_SIZE * NOISE_SIZE];
        java.util.Random rnd = new java.util.Random(42);
        for (int i = 0; i < pixels.length; i++) {
            int v = rnd.nextInt(256);
            pixels[i] = Color.argb(v > 128 ? 18 : 0, v, v, v);
        }
        bmp.setPixels(pixels, 0, NOISE_SIZE, 0, 0, NOISE_SIZE, NOISE_SIZE);
        return bmp;
    }
}
