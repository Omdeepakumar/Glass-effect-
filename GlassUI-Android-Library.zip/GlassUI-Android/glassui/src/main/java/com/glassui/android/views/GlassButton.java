package com.glassui.android.views;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.widget.AppCompatButton;

import com.glassui.android.GlassConfig;
import com.glassui.android.GlassRenderer;
import com.glassui.android.R;
import com.glassui.android.utils.GlassAttrReader;

/**
 * GlassButton — A fully-styled glass button with hover and press animations.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * XML:
 *   <com.glassui.android.views.GlassButton
 *       android:layout_width="wrap_content"
 *       android:layout_height="48dp"
 *       android:text="Sign In"
 *       android:textColor="@color/white"
 *       app:glass_theme="neon_blue"
 *       app:glass_corner_radius="24dp"
 *       app:glass_ripple_enabled="true" />
 *
 * ─────────────────────────────────────────────────────────────────────────
 * Java:
 *   GlassButton btn = new GlassButton(context);
 *   btn.setGlassConfig(GlassConfig.AURORA());
 *   btn.setText("Submit");
 *   btn.setOnClickListener(v -> doSomething());
 * ─────────────────────────────────────────────────────────────────────────
 *
 * @version 1.0
 */
public class GlassButton extends AppCompatButton {

    private GlassRenderer renderer;
    private GlassConfig config;

    // Press animation
    private float pressScale     = 1f;
    private float brightenAmount = 0f;
    private ValueAnimator pressAnimator;
    private ValueAnimator releaseAnimator;
    private boolean rippleEnabled = true;

    // Ripple
    private float rippleX, rippleY, rippleRadius;
    private int   rippleAlpha;
    private ValueAnimator rippleAnimator;
    private final Paint ripplePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    // ─── Constructors ─────────────────────────────────────────────────────

    public GlassButton(Context context) {
        super(context);
        init(context, null);
    }

    public GlassButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public GlassButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    // ─── Init ─────────────────────────────────────────────────────────────

    private void init(Context ctx, AttributeSet attrs) {
        setWillNotDraw(false);
        setBackground(null);
        setAllCaps(false);

        config = (attrs != null)
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();

        if (attrs != null) {
            TypedArray a = ctx.obtainStyledAttributes(attrs, R.styleable.GlassButton);
            rippleEnabled = a.getBoolean(R.styleable.GlassButton_glass_ripple_enabled, true);
            a.recycle();
        }

        renderer = new GlassRenderer(config);
        setTextColor(config.textColor);

        // Press scale animator
        pressAnimator = ValueAnimator.ofFloat(1f, 0.96f);
        pressAnimator.setDuration(80);
        pressAnimator.setInterpolator(new DecelerateInterpolator());
        pressAnimator.addUpdateListener(a -> {
            pressScale     = (float) a.getAnimatedValue();
            brightenAmount = (1f - pressScale) * 60f;
            invalidate();
        });

        releaseAnimator = ValueAnimator.ofFloat(0.96f, 1f);
        releaseAnimator.setDuration(160);
        releaseAnimator.setInterpolator(new DecelerateInterpolator());
        releaseAnimator.addUpdateListener(a -> {
            pressScale     = (float) a.getAnimatedValue();
            brightenAmount = (1f - pressScale) * 60f;
            invalidate();
        });
    }

    // ─── Touch ────────────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                rippleX = event.getX();
                rippleY = event.getY();
                if (rippleEnabled) startRipple();
                if (releaseAnimator.isRunning()) releaseAnimator.cancel();
                pressAnimator.start();
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (pressAnimator.isRunning()) pressAnimator.cancel();
                releaseAnimator.start();
                break;
        }
        return super.onTouchEvent(event);
    }

    private void startRipple() {
        rippleRadius = 0f;
        rippleAlpha  = 80;
        rippleAnimator = ValueAnimator.ofFloat(0f, Math.max(getWidth(), getHeight()) * 1.2f);
        rippleAnimator.setDuration(400);
        rippleAnimator.setInterpolator(new DecelerateInterpolator());
        rippleAnimator.addUpdateListener(a -> {
            rippleRadius = (float) a.getAnimatedValue();
            rippleAlpha  = (int)(80 * (1f - a.getAnimatedFraction()));
            invalidate();
        });
        rippleAnimator.start();
    }

    // ─── Drawing ──────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();

        // Scale transform for press effect
        if (pressScale != 1f) {
            float pivotX = w / 2f;
            float pivotY = h / 2f;
            canvas.save();
            canvas.scale(pressScale, pressScale, pivotX, pivotY);
        }

        // Draw glass (with optional brightness boost on press)
        if (brightenAmount > 0) {
            GlassConfig brighter = new GlassConfig.Builder()
                    .glassColor(brighten(config.glassColor, (int)brightenAmount))
                    .glassOpacity(config.glassOpacity)
                    .cornerRadii(config.cornerRadiusTL, config.cornerRadiusTR,
                                 config.cornerRadiusBL, config.cornerRadiusBR)
                    .borderColor(config.borderColor).borderOpacity(config.borderOpacity)
                    .borderWidth(config.borderWidth)
                    .shadow(config.shadowColor, config.shadowOpacity * 0.5f,
                            config.shadowRadius, config.shadowDx, config.shadowDy)
                    .highlightOpacity(config.highlightOpacity)
                    .textColor(config.textColor)
                    .build();
            new GlassRenderer(brighter).draw(canvas, 0, 0, w, h);
        } else {
            renderer.draw(canvas, 0, 0, w, h);
        }

        // Ripple
        if (rippleEnabled && rippleRadius > 0 && rippleAlpha > 0) {
            int saved = canvas.save();
            clipToShape(canvas, w, h);
            ripplePaint.setColor(Color.argb(rippleAlpha, 255, 255, 255));
            canvas.drawCircle(rippleX, rippleY, rippleRadius, ripplePaint);
            canvas.restoreToCount(saved);
        }

        if (pressScale != 1f) canvas.restore();

        super.onDraw(canvas);
    }

    private void clipToShape(Canvas canvas, int w, int h) {
        Path p = new Path();
        RectF r = new RectF(0, 0, w, h);
        float cr = config.cornerRadiusTL;
        p.addRoundRect(r, cr, cr, Path.Direction.CW);
        canvas.clipPath(p);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────

    private int brighten(int color, int amount) {
        return Color.argb(Color.alpha(color),
                Math.min(255, Color.red(color)   + amount),
                Math.min(255, Color.green(color) + amount),
                Math.min(255, Color.blue(color)  + amount));
    }

    // ─── Config API ───────────────────────────────────────────────────────

    public GlassButton setGlassConfig(GlassConfig config) {
        this.config = config;
        renderer.setConfig(config);
        setTextColor(config.textColor);
        invalidate();
        return this;
    }

    public GlassButton setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }

    public GlassConfig getGlassConfig() { return config; }
}
