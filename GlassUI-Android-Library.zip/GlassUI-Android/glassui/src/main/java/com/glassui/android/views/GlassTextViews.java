package com.glassui.android.views;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.animation.DecelerateInterpolator;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;

import com.glassui.android.GlassConfig;
import com.glassui.android.GlassRenderer;
import com.glassui.android.R;
import com.glassui.android.utils.GlassAttrReader;

// ═══════════════════════════════════════════════════════════════════════════
//  GlassEditText
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GlassEditText — EditText with glass inset background and focus glow.
 *
 * XML:
 *   <com.glassui.android.views.GlassEditText
 *       android:layout_width="match_parent"
 *       android:layout_height="52dp"
 *       android:hint="Enter email..."
 *       android:textColorHint="#80FFFFFF"
 *       android:textColor="@color/white"
 *       app:glass_theme="frost"
 *       app:glass_corner_radius="14dp"
 *       app:glass_focus_glow_enabled="true" />
 *
 * Java:
 *   GlassEditText field = new GlassEditText(context);
 *   field.setGlassConfig(GlassConfig.NEON_BLUE());
 *   field.setHint("Username");
 */
public class GlassEditText extends AppCompatEditText {

    private GlassRenderer renderer;
    private GlassConfig config;

    private boolean focusGlowEnabled = true;
    private float   focusGlowRadius  = 18f;
    private float   glowProgress     = 0f;
    private ValueAnimator glowAnimator;

    // ─── Constructors ─────────────────────────────────────────────────────

    public GlassEditText(Context context) {
        super(context); init(context, null);
    }

    public GlassEditText(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }

    public GlassEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle); init(context, attrs);
    }

    // ─── Init ─────────────────────────────────────────────────────────────

    private void init(Context ctx, AttributeSet attrs) {
        setWillNotDraw(false);
        setBackground(null);

        config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();

        if (attrs != null) {
            TypedArray a = ctx.obtainStyledAttributes(attrs, R.styleable.GlassEditText);
            focusGlowEnabled = a.getBoolean(R.styleable.GlassEditText_glass_focus_glow_enabled, true);
            focusGlowRadius  = a.getDimension(R.styleable.GlassEditText_glass_focus_glow_radius, 18f);
            a.recycle();
        }

        renderer = new GlassRenderer(config);
        setTextColor(config.textColor);

        // Focus glow animator
        glowAnimator = new ValueAnimator();
        glowAnimator.setDuration(250);
        glowAnimator.setInterpolator(new DecelerateInterpolator());
        glowAnimator.addUpdateListener(a -> {
            glowProgress = (float) a.getAnimatedValue();
            invalidate();
        });

        setOnFocusChangeListener((v, hasFocus) -> {
            if (!focusGlowEnabled) return;
            glowAnimator.cancel();
            glowAnimator.setFloatValues(glowProgress, hasFocus ? 1f : 0f);
            glowAnimator.start();
        });
    }

    // ─── Drawing ──────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();

        // Inset glass background
        renderer.drawInset(canvas, 0, 0, w, h);

        // Focus glow
        if (focusGlowEnabled && glowProgress > 0.05f) {
            int bc = config.borderColor;
            int alpha = (int)(glowProgress * 160);
            renderer.drawGlow(canvas, 0, 0, w, h, bc, alpha, focusGlowRadius * glowProgress);
        }

        super.onDraw(canvas);
    }

    // ─── Config API ───────────────────────────────────────────────────────

    public GlassEditText setGlassConfig(GlassConfig config) {
        this.config = config;
        renderer.setConfig(config);
        setTextColor(config.textColor);
        invalidate();
        return this;
    }

    public GlassEditText setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }
}


// ═══════════════════════════════════════════════════════════════════════════
//  GlassTextView
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GlassTextView — TextView with optional glass pill/badge background.
 *
 * XML:
 *   <com.glassui.android.views.GlassTextView
 *       android:layout_width="wrap_content"
 *       android:layout_height="wrap_content"
 *       android:text="● Online"
 *       android:padding="8dp"
 *       app:glass_theme="aurora" />
 *
 * To show a glass pill behind the text, set glass_theme and some padding.
 * To show plain text only (no glass bg), set glass_opacity="0" glass_border_opacity="0".
 */
class GlassTextView extends AppCompatTextView {

    private GlassRenderer renderer;
    private GlassConfig config;
    private boolean drawBackground = true;

    public GlassTextView(Context context) {
        super(context); init(context, null);
    }

    public GlassTextView(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }

    public GlassTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle); init(context, attrs);
    }

    private void init(Context ctx, AttributeSet attrs) {
        setWillNotDraw(false);
        setBackground(null);
        config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();
        renderer = new GlassRenderer(config);
        setTextColor(config.textColor);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (drawBackground) {
            renderer.draw(canvas, 0, 0, getWidth(), getHeight());
        }
        super.onDraw(canvas);
    }

    public GlassTextView setGlassConfig(GlassConfig config) {
        this.config = config;
        renderer.setConfig(config);
        setTextColor(config.textColor);
        invalidate();
        return this;
    }

    public GlassTextView setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }

    /** Pass false to draw only text, no glass background */
    public GlassTextView setDrawGlassBackground(boolean draw) {
        drawBackground = draw;
        invalidate();
        return this;
    }
}
