package com.glassui.android;

import android.graphics.Color;

/**
 * GlassConfig — Theme configuration for all GlassUI components.
 *
 * Use preset themes or build a custom one with the Builder.
 *
 * Example:
 *   GlassConfig config = GlassConfig.NEON_BLUE();
 *
 *   // Or custom:
 *   GlassConfig config = new GlassConfig.Builder()
 *       .glassColor(Color.parseColor("#2979FF"))
 *       .glassOpacity(0.25f)
 *       .cornerRadius(24f)
 *       .build();
 */
public class GlassConfig {

    // ─── Theme constants (match attrs.xml enum) ───────────────────────────
    public static final int THEME_FROST     = 0;
    public static final int THEME_DARK      = 1;
    public static final int THEME_NEON_BLUE = 2;
    public static final int THEME_NEON_PINK = 3;
    public static final int THEME_AURORA    = 4;
    public static final int THEME_SUNSET    = 5;
    public static final int THEME_CUSTOM    = 6;

    // ─── Fields ───────────────────────────────────────────────────────────
    public final int   glassColor;
    public final float glassOpacity;

    public final float cornerRadiusTL;
    public final float cornerRadiusTR;
    public final float cornerRadiusBL;
    public final float cornerRadiusBR;

    public final int   borderColor;
    public final float borderOpacity;
    public final float borderWidth;

    public final int   shadowColor;
    public final float shadowOpacity;
    public final float shadowRadius;
    public final float shadowDx;
    public final float shadowDy;

    public final float highlightOpacity;

    public final boolean blurEnabled;
    public final float   blurRadius;

    public final boolean noiseEnabled;
    public final int     noiseAlpha;

    public final int textColor;
    public final boolean textShadowEnabled;

    // ─────────────────────────────────────────────────────────────────────

    private GlassConfig(Builder b) {
        glassColor      = b.glassColor;
        glassOpacity    = b.glassOpacity;

        cornerRadiusTL  = b.cornerRadiusTL;
        cornerRadiusTR  = b.cornerRadiusTR;
        cornerRadiusBL  = b.cornerRadiusBL;
        cornerRadiusBR  = b.cornerRadiusBR;

        borderColor     = b.borderColor;
        borderOpacity   = b.borderOpacity;
        borderWidth     = b.borderWidth;

        shadowColor     = b.shadowColor;
        shadowOpacity   = b.shadowOpacity;
        shadowRadius    = b.shadowRadius;
        shadowDx        = b.shadowDx;
        shadowDy        = b.shadowDy;

        highlightOpacity = b.highlightOpacity;

        blurEnabled     = b.blurEnabled;
        blurRadius      = b.blurRadius;

        noiseEnabled    = b.noiseEnabled;
        noiseAlpha      = b.noiseAlpha;

        textColor       = b.textColor;
        textShadowEnabled = b.textShadowEnabled;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRESET THEMES
    // ═══════════════════════════════════════════════════════════════════════

    /** ❄ Classic frosted white glass */
    public static GlassConfig FROST() {
        return new Builder()
                .glassColor(Color.WHITE).glassOpacity(0.18f)
                .cornerRadius(20f)
                .borderColor(Color.WHITE).borderOpacity(0.45f).borderWidth(1.5f)
                .shadow(Color.BLACK, 0.25f, 20f, 0f, 8f)
                .highlightOpacity(0.35f)
                .textColor(Color.WHITE).textShadow(true)
                .noise(true, 12)
                .build();
    }

    /** 🌑 Deep dark glass */
    public static GlassConfig DARK() {
        return new Builder()
                .glassColor(Color.parseColor("#0A0A1E")).glassOpacity(0.55f)
                .cornerRadius(18f)
                .borderColor(Color.WHITE).borderOpacity(0.15f).borderWidth(1f)
                .shadow(Color.BLACK, 0.6f, 24f, 0f, 10f)
                .highlightOpacity(0.10f)
                .textColor(Color.parseColor("#DCDCf0")).textShadow(true)
                .noise(false, 0)
                .build();
    }

    /** 💙 Neon Blue / Cyan glow */
    public static GlassConfig NEON_BLUE() {
        return new Builder()
                .glassColor(Color.parseColor("#0078FF")).glassOpacity(0.22f)
                .cornerRadius(16f)
                .borderColor(Color.parseColor("#50B4FF")).borderOpacity(0.75f).borderWidth(1.5f)
                .shadow(Color.parseColor("#0064FF"), 0.55f, 20f, 0f, 0f)
                .highlightOpacity(0.28f)
                .textColor(Color.parseColor("#C8E6FF")).textShadow(true)
                .noise(false, 0)
                .build();
    }

    /** 💗 Neon Pink / Magenta glow */
    public static GlassConfig NEON_PINK() {
        return new Builder()
                .glassColor(Color.parseColor("#C800C8")).glassOpacity(0.22f)
                .cornerRadius(16f)
                .borderColor(Color.parseColor("#FF64FF")).borderOpacity(0.70f).borderWidth(1.5f)
                .shadow(Color.parseColor("#B400C8"), 0.50f, 20f, 0f, 0f)
                .highlightOpacity(0.28f)
                .textColor(Color.parseColor("#FFDCFF")).textShadow(true)
                .noise(false, 0)
                .build();
    }

    /** 🌌 Aurora green-teal */
    public static GlassConfig AURORA() {
        return new Builder()
                .glassColor(Color.parseColor("#00C896")).glassOpacity(0.22f)
                .cornerRadius(22f)
                .borderColor(Color.parseColor("#64FFC8")).borderOpacity(0.65f).borderWidth(1.5f)
                .shadow(Color.parseColor("#009664"), 0.40f, 18f, 0f, 6f)
                .highlightOpacity(0.28f)
                .textColor(Color.parseColor("#C8FFF0")).textShadow(true)
                .noise(false, 0)
                .build();
    }

    /** 🌅 Sunset warm orange-red */
    public static GlassConfig SUNSET() {
        return new Builder()
                .glassColor(Color.parseColor("#FF6432")).glassOpacity(0.25f)
                .cornerRadius(18f)
                .borderColor(Color.parseColor("#FFB478")).borderOpacity(0.65f).borderWidth(1.5f)
                .shadow(Color.parseColor("#C83C00"), 0.45f, 18f, 0f, 6f)
                .highlightOpacity(0.30f)
                .textColor(Color.parseColor("#FFF0DC")).textShadow(true)
                .noise(false, 0)
                .build();
    }

    /** Returns preset GlassConfig from theme int */
    public static GlassConfig fromTheme(int theme) {
        switch (theme) {
            case THEME_DARK:      return DARK();
            case THEME_NEON_BLUE: return NEON_BLUE();
            case THEME_NEON_PINK: return NEON_PINK();
            case THEME_AURORA:    return AURORA();
            case THEME_SUNSET:    return SUNSET();
            default:              return FROST();
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────

    /** Returns glassColor with glassOpacity applied */
    public int getGlassFillColor() {
        return applyAlpha(glassColor, glassOpacity);
    }

    /** Returns borderColor with borderOpacity applied */
    public int getBorderPaintColor() {
        return applyAlpha(borderColor, borderOpacity);
    }

    /** Returns shadowColor with shadowOpacity applied */
    public int getShadowPaintColor() {
        return applyAlpha(shadowColor, shadowOpacity);
    }

    /** Returns highlightColor (white) with highlightOpacity */
    public int getHighlightColor() {
        return applyAlpha(Color.WHITE, highlightOpacity);
    }

    private static int applyAlpha(int color, float opacity) {
        int a = Math.max(0, Math.min(255, (int)(opacity * 255)));
        return (color & 0x00FFFFFF) | (a << 24);
    }

    public float getUniformCornerRadius() {
        return cornerRadiusTL;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  BUILDER
    // ═══════════════════════════════════════════════════════════════════════

    public static class Builder {
        int   glassColor      = Color.WHITE;
        float glassOpacity    = 0.18f;

        float cornerRadiusTL  = 16f;
        float cornerRadiusTR  = 16f;
        float cornerRadiusBL  = 16f;
        float cornerRadiusBR  = 16f;

        int   borderColor     = Color.WHITE;
        float borderOpacity   = 0.40f;
        float borderWidth     = 1.5f;

        int   shadowColor     = Color.BLACK;
        float shadowOpacity   = 0.25f;
        float shadowRadius    = 16f;
        float shadowDx        = 0f;
        float shadowDy        = 6f;

        float highlightOpacity = 0.28f;

        boolean blurEnabled   = false;
        float   blurRadius    = 10f;

        boolean noiseEnabled  = false;
        int     noiseAlpha    = 10;

        int  textColor        = Color.WHITE;
        boolean textShadowEnabled = false;

        public Builder glassColor(int color)         { glassColor = color;   return this; }
        public Builder glassOpacity(float v)          { glassOpacity = clamp(v); return this; }

        public Builder cornerRadius(float r) {
            cornerRadiusTL = cornerRadiusTR = cornerRadiusBL = cornerRadiusBR = r;
            return this;
        }
        public Builder cornerRadii(float tl, float tr, float bl, float br) {
            cornerRadiusTL = tl; cornerRadiusTR = tr;
            cornerRadiusBL = bl; cornerRadiusBR = br;
            return this;
        }

        public Builder borderColor(int color)         { borderColor = color;  return this; }
        public Builder borderOpacity(float v)          { borderOpacity = clamp(v); return this; }
        public Builder borderWidth(float w)            { borderWidth = w;      return this; }

        public Builder shadow(int color, float opacity, float radius, float dx, float dy) {
            shadowColor = color; shadowOpacity = clamp(opacity);
            shadowRadius = radius; shadowDx = dx; shadowDy = dy;
            return this;
        }

        public Builder highlightOpacity(float v)       { highlightOpacity = clamp(v); return this; }

        public Builder blur(boolean enabled, float radius) {
            blurEnabled = enabled; blurRadius = radius; return this;
        }

        public Builder noise(boolean enabled, int alpha) {
            noiseEnabled = enabled; noiseAlpha = alpha; return this;
        }

        public Builder textColor(int color)           { textColor = color;    return this; }
        public Builder textShadow(boolean enabled)     { textShadowEnabled = enabled; return this; }

        public GlassConfig build() { return new GlassConfig(this); }

        private float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    }
}
