package com.glassui.android.views;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.glassui.android.GlassConfig;
import com.glassui.android.GlassRenderer;
import com.glassui.android.R;
import com.glassui.android.utils.GlassAttrReader;

// ═══════════════════════════════════════════════════════════════════════════
//  GlassFrameLayout
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GlassFrameLayout — Drop-in replacement for FrameLayout with glass effect.
 *
 * XML:
 *   <com.glassui.android.views.GlassFrameLayout
 *       android:layout_width="match_parent"
 *       android:layout_height="200dp"
 *       app:glass_theme="dark"
 *       app:glass_corner_radius="24dp" />
 */
class GlassFrameLayout extends FrameLayout {

    private GlassRenderer renderer;

    public GlassFrameLayout(Context context) {
        super(context); init(context, null);
    }
    public GlassFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }
    public GlassFrameLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle); init(context, attrs);
    }

    private void init(Context ctx, AttributeSet attrs) {
        setWillNotDraw(false);
        setBackground(null);
        GlassConfig config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();
        renderer = new GlassRenderer(config);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        renderer.draw(canvas, 0, 0, getWidth(), getHeight());
        super.onDraw(canvas);
    }

    public GlassFrameLayout setGlassConfig(GlassConfig config) {
        renderer.setConfig(config); invalidate(); return this;
    }

    public GlassFrameLayout setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }
}


// ═══════════════════════════════════════════════════════════════════════════
//  GlassRelativeLayout
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GlassRelativeLayout — Drop-in replacement for RelativeLayout.
 *
 * XML:
 *   <com.glassui.android.views.GlassRelativeLayout
 *       app:glass_theme="aurora"
 *       app:glass_corner_radius="18dp" />
 */
class GlassRelativeLayout extends RelativeLayout {

    private GlassRenderer renderer;

    public GlassRelativeLayout(Context context) {
        super(context); init(context, null);
    }
    public GlassRelativeLayout(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }
    public GlassRelativeLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle); init(context, attrs);
    }

    private void init(Context ctx, AttributeSet attrs) {
        setWillNotDraw(false);
        setBackground(null);
        GlassConfig config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();
        renderer = new GlassRenderer(config);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        renderer.draw(canvas, 0, 0, getWidth(), getHeight());
        super.onDraw(canvas);
    }

    public GlassRelativeLayout setGlassConfig(GlassConfig config) {
        renderer.setConfig(config); invalidate(); return this;
    }

    public GlassRelativeLayout setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }
}


// ═══════════════════════════════════════════════════════════════════════════
//  GlassConstraintLayout
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GlassConstraintLayout — Drop-in ConstraintLayout with glass effect.
 *
 * XML:
 *   <com.glassui.android.views.GlassConstraintLayout
 *       app:glass_theme="neon_pink"
 *       app:glass_corner_radius="20dp" />
 */
class GlassConstraintLayout extends ConstraintLayout {

    private GlassRenderer renderer;

    public GlassConstraintLayout(Context context) {
        super(context); init(context, null);
    }
    public GlassConstraintLayout(Context context, AttributeSet attrs) {
        super(context, attrs); init(context, attrs);
    }
    public GlassConstraintLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle); init(context, attrs);
    }

    private void init(Context ctx, AttributeSet attrs) {
        setWillNotDraw(false);
        setBackground(null);
        GlassConfig config = attrs != null
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();
        renderer = new GlassRenderer(config);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        renderer.draw(canvas, 0, 0, getWidth(), getHeight());
        super.onDraw(canvas);
    }

    public GlassConstraintLayout setGlassConfig(GlassConfig config) {
        renderer.setConfig(config); invalidate(); return this;
    }

    public GlassConstraintLayout setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }
}
