package com.glassui.android.views;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.LinearLayout;

import com.glassui.android.GlassConfig;
import com.glassui.android.GlassRenderer;
import com.glassui.android.R;
import com.glassui.android.utils.GlassAttrReader;

/**
 * GlassLinearLayout — Drop-in replacement for LinearLayout with glass effect.
 *
 * ─────────────────────────────────────────────────────────────────────────
 * XML Usage:
 * ─────────────────────────────────────────────────────────────────────────
 *
 *   <com.glassui.android.views.GlassLinearLayout
 *       android:layout_width="match_parent"
 *       android:layout_height="wrap_content"
 *       android:orientation="vertical"
 *       android:padding="16dp"
 *       app:glass_theme="neon_blue"
 *       app:glass_corner_radius="20dp">
 *
 *       <!-- your child views here -->
 *
 *   </com.glassui.android.views.GlassLinearLayout>
 *
 * ─────────────────────────────────────────────────────────────────────────
 * Java / Kotlin Usage:
 * ─────────────────────────────────────────────────────────────────────────
 *
 *   GlassLinearLayout layout = new GlassLinearLayout(context);
 *   layout.setGlassConfig(GlassConfig.NEON_BLUE());
 *   layout.addView(myChildView);
 *
 * ─────────────────────────────────────────────────────────────────────────
 * Convert existing LinearLayout:
 *   Just replace <LinearLayout with <com.glassui.android.views.GlassLinearLayout
 *   and add app:glass_theme="frost" (or any theme).
 * ─────────────────────────────────────────────────────────────────────────
 *
 * @version 1.0
 */
public class GlassLinearLayout extends LinearLayout {

    private GlassRenderer renderer;

    // ─── Constructors ─────────────────────────────────────────────────────

    public GlassLinearLayout(Context context) {
        super(context);
        init(context, null);
    }

    public GlassLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public GlassLinearLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    // ─── Init ─────────────────────────────────────────────────────────────

    private void init(Context ctx, AttributeSet attrs) {
        // Required for onDraw to be called
        setWillNotDraw(false);

        // Read XML attrs (or use default FROST theme)
        GlassConfig config = (attrs != null)
                ? GlassAttrReader.read(ctx, attrs, R.styleable.GlassView)
                : GlassConfig.FROST();

        renderer = new GlassRenderer(config);

        // No default background
        setBackground(null);
    }

    // ─── Drawing ──────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        renderer.draw(canvas, 0, 0, getWidth(), getHeight());
        super.onDraw(canvas);
    }

    // ─── Config API ───────────────────────────────────────────────────────

    /**
     * Set a new glass configuration and repaint.
     */
    public GlassLinearLayout setGlassConfig(GlassConfig config) {
        renderer.setConfig(config);
        invalidate();
        return this;
    }

    /**
     * Set a preset glass theme.
     */
    public GlassLinearLayout setGlassTheme(int theme) {
        return setGlassConfig(GlassConfig.fromTheme(theme));
    }

    public GlassConfig getGlassConfig() {
        return renderer.getConfig();
    }
}
