package com.glassui.android.utils;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;

import com.glassui.android.GlassConfig;
import com.glassui.android.R;

/**
 * GlassAttrReader — Reads XML attributes from AttributeSet into a GlassConfig.
 *
 * Used internally by all GlassUI views so they all share the same
 * XML attribute set (glass_theme, glass_color, etc.)
 */
public class GlassAttrReader {

    private GlassAttrReader() {}

    /**
     * Parse GlassView styleable attributes from XML into a GlassConfig.Builder.
     * Call view.obtainStyledAttributes(attrs, R.styleable.GlassView).
     */
    public static GlassConfig read(Context ctx, AttributeSet attrs, int[] styleableRes) {
        if (attrs == null) return GlassConfig.FROST();

        TypedArray a = ctx.obtainStyledAttributes(attrs, R.styleable.GlassView);
        try {
            // ── Check preset theme first ──────────────────────────────────
            int themeEnum = a.getInt(R.styleable.GlassView_glass_theme, -1);
            GlassConfig base = (themeEnum >= 0)
                    ? GlassConfig.fromTheme(themeEnum)
                    : GlassConfig.FROST();

            GlassConfig.Builder b = copyToBuilder(base);

            // ── Override individual attrs if explicitly set ─────────────
            if (a.hasValue(R.styleable.GlassView_glass_color))
                b.glassColor(a.getColor(R.styleable.GlassView_glass_color, base.glassColor));

            if (a.hasValue(R.styleable.GlassView_glass_opacity))
                b.glassOpacity(a.getFloat(R.styleable.GlassView_glass_opacity, base.glassOpacity));

            // Corner radius — uniform or per-corner
            if (a.hasValue(R.styleable.GlassView_glass_corner_radius)) {
                float cr = a.getDimension(R.styleable.GlassView_glass_corner_radius, base.cornerRadiusTL);
                b.cornerRadius(cr);
            } else {
                float tl = a.getDimension(R.styleable.GlassView_glass_corner_radius_tl, base.cornerRadiusTL);
                float tr = a.getDimension(R.styleable.GlassView_glass_corner_radius_tr, base.cornerRadiusTR);
                float bl = a.getDimension(R.styleable.GlassView_glass_corner_radius_bl, base.cornerRadiusBL);
                float br = a.getDimension(R.styleable.GlassView_glass_corner_radius_br, base.cornerRadiusBR);
                b.cornerRadii(tl, tr, bl, br);
            }

            if (a.hasValue(R.styleable.GlassView_glass_border_color))
                b.borderColor(a.getColor(R.styleable.GlassView_glass_border_color, base.borderColor));

            if (a.hasValue(R.styleable.GlassView_glass_border_opacity))
                b.borderOpacity(a.getFloat(R.styleable.GlassView_glass_border_opacity, base.borderOpacity));

            if (a.hasValue(R.styleable.GlassView_glass_border_width))
                b.borderWidth(a.getDimension(R.styleable.GlassView_glass_border_width, base.borderWidth));

            if (a.hasValue(R.styleable.GlassView_glass_shadow_color) ||
                a.hasValue(R.styleable.GlassView_glass_shadow_opacity) ||
                a.hasValue(R.styleable.GlassView_glass_shadow_radius)) {
                b.shadow(
                        a.getColor(R.styleable.GlassView_glass_shadow_color,     base.shadowColor),
                        a.getFloat(R.styleable.GlassView_glass_shadow_opacity,   base.shadowOpacity),
                        a.getDimension(R.styleable.GlassView_glass_shadow_radius, base.shadowRadius),
                        a.getDimension(R.styleable.GlassView_glass_shadow_dx,     base.shadowDx),
                        a.getDimension(R.styleable.GlassView_glass_shadow_dy,     base.shadowDy));
            }

            if (a.hasValue(R.styleable.GlassView_glass_highlight_opacity))
                b.highlightOpacity(a.getFloat(R.styleable.GlassView_glass_highlight_opacity,
                        base.highlightOpacity));

            if (a.hasValue(R.styleable.GlassView_glass_blur_enabled))
                b.blur(a.getBoolean(R.styleable.GlassView_glass_blur_enabled, base.blurEnabled),
                       a.getFloat(R.styleable.GlassView_glass_blur_radius, base.blurRadius));

            if (a.hasValue(R.styleable.GlassView_glass_noise_enabled))
                b.noise(a.getBoolean(R.styleable.GlassView_glass_noise_enabled, base.noiseEnabled),
                        a.getInt(R.styleable.GlassView_glass_noise_alpha, base.noiseAlpha));

            return b.build();

        } finally {
            a.recycle();
        }
    }

    private static GlassConfig.Builder copyToBuilder(GlassConfig c) {
        return new GlassConfig.Builder()
                .glassColor(c.glassColor)
                .glassOpacity(c.glassOpacity)
                .cornerRadii(c.cornerRadiusTL, c.cornerRadiusTR, c.cornerRadiusBL, c.cornerRadiusBR)
                .borderColor(c.borderColor)
                .borderOpacity(c.borderOpacity)
                .borderWidth(c.borderWidth)
                .shadow(c.shadowColor, c.shadowOpacity, c.shadowRadius, c.shadowDx, c.shadowDy)
                .highlightOpacity(c.highlightOpacity)
                .blur(c.blurEnabled, c.blurRadius)
                .noise(c.noiseEnabled, c.noiseAlpha)
                .textColor(c.textColor)
                .textShadow(c.textShadowEnabled);
    }
}
