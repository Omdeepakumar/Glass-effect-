# 🪟 GlassUI — Android Glassmorphism Library

![API](https://img.shields.io/badge/API-21%2B-brightgreen)
![License](https://img.shields.io/badge/License-MIT-blue)
![JitPack](https://img.shields.io/badge/JitPack-1.0.0-orange)

> Beautiful glassmorphism components for Android — frosted glass, neon glow, blur effects.
> Works with XML and Java/Kotlin. Drop-in replacement for LinearLayout and other layouts.

---

## 📸 Preview

| Frost | Neon Blue | Aurora | Dark |
|---|---|---|---|
| ❄ White glass | 💙 Cyan glow | 🌌 Green teal | 🌑 Deep dark |

---

## ⚡ Add to Project (JitPack)

### Step 1 — Add JitPack repository

In your root `settings.gradle`:
```gradle
dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
        maven { url 'https://jitpack.io' }   // ← add this
    }
}
```

### Step 2 — Add dependency

In your app's `build.gradle`:
```gradle
dependencies {
    implementation 'com.github.YOUR_GITHUB_USERNAME:GlassUI-Android:1.0.0'
}
```

> Replace `YOUR_GITHUB_USERNAME` with the actual GitHub username after upload.

---

## 🎨 6 Built-in Themes

| Theme XML value | Java constant | Look |
|---|---|---|
| `frost` | `GlassConfig.FROST()` | ❄ White frosted glass |
| `dark` | `GlassConfig.DARK()` | 🌑 Deep dark glass |
| `neon_blue` | `GlassConfig.NEON_BLUE()` | 💙 Cyan neon glow |
| `neon_pink` | `GlassConfig.NEON_PINK()` | 💗 Magenta neon glow |
| `aurora` | `GlassConfig.AURORA()` | 🌌 Green-teal aurora |
| `sunset` | `GlassConfig.SUNSET()` | 🌅 Orange-red warm |

---

## 📋 All Components

| Component | Extends | Use for |
|---|---|---|
| `GlassLinearLayout` | LinearLayout | Panels, containers |
| `GlassFrameLayout` | FrameLayout | Overlays, wrappers |
| `GlassRelativeLayout` | RelativeLayout | Absolute positioning |
| `GlassConstraintLayout` | ConstraintLayout | Complex layouts |
| `GlassButton` | AppCompatButton | Buttons, CTAs |
| `GlassEditText` | AppCompatEditText | Input fields |
| `GlassTextView` | AppCompatTextView | Text, badges, labels |
| `GlassCard` | FrameLayout | Cards with title header |
| `GlassProgressBar` | View | Animated progress bars |
| `GlassSlider` | View | Custom seekbar |

---

## 🔧 XML Usage

### Add namespace to root layout:
```xml
xmlns:app="http://schemas.android.com/apk/res-auto"
```

### GlassLinearLayout (convert existing LinearLayout)
```xml
<!-- BEFORE -->
<LinearLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:padding="16dp">
    ...
</LinearLayout>

<!-- AFTER — just change the tag and add glass_theme -->
<com.glassui.android.views.GlassLinearLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:padding="16dp"
    app:glass_theme="frost"
    app:glass_corner_radius="20dp">
    ...
</com.glassui.android.views.GlassLinearLayout>
```

### GlassCard
```xml
<com.glassui.android.views.GlassCard
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    app:glass_theme="neon_blue"
    app:glass_corner_radius="20dp"
    app:glass_card_title="Sign In"
    app:glass_header_divider="true">

    <!-- Your content -->
    <LinearLayout ...>
        <com.glassui.android.views.GlassEditText ... />
        <com.glassui.android.views.GlassButton ... />
    </LinearLayout>

</com.glassui.android.views.GlassCard>
```

### GlassButton
```xml
<com.glassui.android.views.GlassButton
    android:layout_width="match_parent"
    android:layout_height="52dp"
    android:text="Sign In"
    android:textStyle="bold"
    app:glass_theme="aurora"
    app:glass_corner_radius="14dp"
    app:glass_ripple_enabled="true" />
```

### GlassEditText
```xml
<com.glassui.android.views.GlassEditText
    android:layout_width="match_parent"
    android:layout_height="52dp"
    android:hint="Email address"
    android:textColor="#FFFFFF"
    android:textColorHint="#80FFFFFF"
    android:paddingHorizontal="16dp"
    app:glass_theme="neon_blue"
    app:glass_corner_radius="14dp"
    app:glass_focus_glow_enabled="true" />
```

### GlassProgressBar
```xml
<com.glassui.android.views.GlassProgressBar
    android:id="@+id/progress"
    android:layout_width="match_parent"
    android:layout_height="22dp"
    app:glass_theme="neon_blue"
    app:glass_progress="0.65"
    app:glass_show_label="true"
    app:glass_animate_on_attach="true" />
```

### GlassSlider
```xml
<com.glassui.android.views.GlassSlider
    android:id="@+id/slider"
    android:layout_width="match_parent"
    android:layout_height="44dp"
    app:glass_theme="neon_pink"
    app:glass_min="0"
    app:glass_max="100"
    app:glass_value="50" />
```

### GlassTextView — Badge / Pill
```xml
<com.glassui.android.views.GlassTextView
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:paddingHorizontal="12dp"
    android:paddingVertical="6dp"
    android:text="● Online"
    android:textStyle="bold"
    app:glass_theme="aurora" />
```

### Custom theme via XML
```xml
<com.glassui.android.views.GlassLinearLayout
    app:glass_theme="custom"
    app:glass_color="#8B0000"
    app:glass_opacity="0.30"
    app:glass_corner_radius="16dp"
    app:glass_border_color="#FF4444"
    app:glass_border_opacity="0.7"
    app:glass_highlight_opacity="0.25"
    ... />
```

---

## ☕ Java / Kotlin Usage

### Java
```java
// LinearLayout with glass
GlassLinearLayout panel = new GlassLinearLayout(context);
panel.setGlassConfig(GlassConfig.NEON_BLUE());
panel.setOrientation(LinearLayout.VERTICAL);

// Button
GlassButton btn = new GlassButton(context);
btn.setGlassConfig(GlassConfig.AURORA());
btn.setText("Submit");
btn.setOnClickListener(v -> doSomething());

// Progress bar
GlassProgressBar bar = findViewById(R.id.progress);
bar.setProgress(0.75f);   // smooth animated

// Slider listener
GlassSlider slider = findViewById(R.id.slider);
slider.addChangeListener(value -> Log.d("TAG", "Value: " + value));

// Custom config
GlassConfig myConfig = new GlassConfig.Builder()
    .glassColor(Color.parseColor("#FF6432"))
    .glassOpacity(0.25f)
    .cornerRadius(20f)
    .borderColor(Color.parseColor("#FFB478"))
    .borderOpacity(0.65f)
    .borderWidth(1.5f)
    .shadow(Color.BLACK, 0.35f, 18f, 0f, 6f)
    .highlightOpacity(0.30f)
    .textColor(Color.WHITE)
    .build();
panel.setGlassConfig(myConfig);
```

### Kotlin
```kotlin
val panel = GlassLinearLayout(context).apply {
    setGlassConfig(GlassConfig.DARK())
    orientation = LinearLayout.VERTICAL
}

val btn = GlassButton(context).apply {
    setGlassConfig(GlassConfig.AURORA())
    text = "Submit"
    setOnClickListener { doSomething() }
}

val config = GlassConfig.Builder()
    .glassColor(Color.parseColor("#0078FF"))
    .glassOpacity(0.22f)
    .cornerRadius(16f)
    .build()
```

---

## 🖼 Background Setup

Glass effects look best on dark/gradient backgrounds.
Add to your Activity background or root layout:

```xml
android:background="@drawable/bg_gradient"
```

`res/drawable/bg_gradient.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android">
    <gradient
        android:startColor="#0A1628"
        android:centerColor="#0D1B3E"
        android:endColor="#1A0D2E"
        android:angle="135"
        android:type="linear" />
</shape>
```

Or in Java/Kotlin:
```java
getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0D1B3E")));
```

---

## 📐 All XML Attributes

| Attribute | Type | Default | Description |
|---|---|---|---|
| `glass_theme` | enum | `frost` | Preset theme (frost/dark/neon_blue/neon_pink/aurora/sunset/custom) |
| `glass_color` | color | white | Base glass fill color |
| `glass_opacity` | float | 0.18 | Glass fill transparency (0.0–1.0) |
| `glass_corner_radius` | dimension | 16dp | Corner radius (uniform) |
| `glass_corner_radius_tl/tr/bl/br` | dimension | 16dp | Per-corner radius |
| `glass_border_color` | color | white | Border stroke color |
| `glass_border_opacity` | float | 0.40 | Border transparency |
| `glass_border_width` | dimension | 1.5dp | Border stroke width |
| `glass_shadow_color` | color | black | Shadow color |
| `glass_shadow_opacity` | float | 0.25 | Shadow transparency |
| `glass_shadow_radius` | dimension | 16dp | Shadow blur size |
| `glass_shadow_dx/dy` | dimension | 0/6dp | Shadow offset |
| `glass_highlight_opacity` | float | 0.28 | Top shimmer intensity |
| `glass_blur_enabled` | boolean | false | Enable real blur (API 31+) |
| `glass_blur_radius` | float | 10 | Blur intensity |
| `glass_noise_enabled` | boolean | false | Frosted noise grain overlay |
| `glass_noise_alpha` | integer | 10 | Noise layer alpha (0–255) |

### GlassButton extras
| `glass_ripple_enabled` | boolean | true | Enable ripple on tap |

### GlassEditText extras
| `glass_focus_glow_enabled` | boolean | true | Glow ring on focus |
| `glass_focus_glow_radius` | dimension | 18dp | Focus glow spread |

### GlassCard extras
| `glass_card_title` | string | — | Title shown in header |
| `glass_card_title_size` | dimension | 14sp | Title text size |
| `glass_header_height` | dimension | 48dp | Header bar height |
| `glass_header_divider` | boolean | true | Show divider below header |

### GlassProgressBar extras
| `glass_progress` | float | 0.0 | Initial progress (0.0–1.0) |
| `glass_show_label` | boolean | true | Show % label on bar |
| `glass_animate_on_attach` | boolean | true | Animate from 0 on attach |

### GlassSlider extras
| `glass_min` | integer | 0 | Minimum value |
| `glass_max` | integer | 100 | Maximum value |
| `glass_value` | integer | 50 | Initial value |

---

## 📋 Requirements

- **Min SDK:** API 21 (Android 5.0 Lollipop)
- **Target SDK:** API 34
- **Java:** 8+
- **Dependencies:** `androidx.appcompat`, `constraintlayout`, `material`

---

## 📄 License

```
MIT License

Copyright (c) 2025

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so.
```

---

## 🙌 Contributing

Pull requests are welcome! Please open an issue first for major changes.

---

## ⭐ Star this repo if it helped you!
